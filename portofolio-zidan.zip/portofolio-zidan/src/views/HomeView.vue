<script setup>
import Navbar from '@/components/Navbar.vue'
import Hero from '@/components/Hero.vue'
import About from '@/components/About.vue'
import Skill from '@/components/Skill.vue'
import Footer from '@/components/Footer.vue'
</script>


<template>
  <Navbar />
  <Hero />          
  <About />         
  <Skill />         
  <Footer />       
  </template>
