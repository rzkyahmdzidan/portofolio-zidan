<template>
  <div data-aos="fade-up" class="not-found w-full h-screen  flex justify-center items-center">
    <div class="container-40 ">
      <img src="@/assets/img/404.svg" alt="404">
      <h1>404 - Page Not Found</h1>
      <p>The page you are looking for does not exist.</p>
      <router-link to="/" class="text-red-400">Go Back to Home</router-link>
    </div>
  </div>
</template>
